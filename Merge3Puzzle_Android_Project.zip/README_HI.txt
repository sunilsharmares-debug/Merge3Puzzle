MERGE 3 PUZZLE — ANDROID APK SOURCE PROJECT

यह Android Studio project है। इसमें गेम HTML को Android WebView के अंदर चलाया जाता है।
यह ZIP अपने आप APK नहीं है; APK GitHub Actions या Android Studio से build होगा।

सबसे आसान तरीका (फ्री GitHub Actions):
1. ZIP को extract करें।
2. GitHub पर नया PUBLIC repository बनाएँ।
3. इस ZIP की सभी फाइलें repository में upload करें और commit करें।
4. GitHub में Actions tab खोलें।
5. 'Build Android APK' workflow चुनें और Run workflow दबाएँ (या main पर push के बाद अपने आप चलेगा)।
6. Build पूरा होने पर workflow run के नीचे Artifacts में Merge3Puzzle-debug-apk डाउनलोड करें।
7. ZIP खोलें; app-debug.apk Android फोन में install करें। पहली बार फोन Settings में इस source से install की अनुमति देनी पड़ सकती है।

नोट:
- यह debug APK है, Play Store release के लिए signed release build और privacy/ad policy setup अलग से करना होगा।
- फिलहाल कोई AdMob SDK या real-money reward/redemption integration शामिल नहीं है।
- गेम का स्कोर/कॉइन browser local storage में सेव होते हैं; cloud account sync नहीं है।
- GitHub Actions की free usage limits लागू हो सकती हैं।
